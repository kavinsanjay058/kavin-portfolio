import React from "react";

const Footer = () => (
  <footer style={{ background: "#222", color: "#fff", textAlign: "center", padding: "1rem" }}>
    <p>Contact: 9942950320 | kavinsanjay873@gmail.com</p>
    <p>LinkedIn: <a href="https://linkedin.com/in/dhanushbalan24" style={{ color: "#0af" }}>dhanushbalan24</a></p>
    <p>Portfolio: <a href="#" style={{ color: "#0af" }}>Portfolio Link</a></p>
    <a href="https://linkedin.com/in/dhanushbalan24" style={{ color: "#0af" }}>
  linkedin.com/in/dhanushbalan24
</a>

  </footer>
);

export default Footer;